#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>

// gcc -Wall -g -o client client.c

#define MAXLINE 4096

#ifndef SERVER_PORT 
# define SERVER_PORT 10002
#endif //SERVER_PORT


int main(int argc, char *argv[]){

    int sockfd;
    int port = SERVER_PORT;
    struct sockaddr_in servaddr;
    char sendline[MAXLINE] = {0};
    char recvline[MAXLINE] = {0};
    char ip_addr[50] = {0};

    if (argc > 1){
        strcpy(ip_addr, argv[1]);
    }
    else{
        printf("ERROR - Must provide ip address\n");
        exit(EXIT_FAILURE);
    }
    if (argc > 2){
        port = atoi(argv[2]);
    }

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&servaddr, 0, sizeof(servaddr));
    
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);

    inet_pton(AF_INET, ip_addr, &servaddr.sin_addr.s_addr);
    if (connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) != 0){
        perror("could not connect");
        exit(EXIT_FAILURE);
    }
    fputs("ready >> ", stdout);
    while (fgets(sendline, sizeof(sendline), stdin) != NULL){
        sendline[strlen(sendline) - 1] = 0;
        memset(recvline, 0, sizeof(recvline));
        write(sockfd, sendline, strlen(sendline));
        if(read(sockfd, recvline, sizeof(recvline)) == 0){
            perror("socket is closed");
            break;
        }
        fprintf(stdout, "back from server: <%s>\n", recvline);
        fputs("ready >> ", stdout);
    }

    return EXIT_SUCCESS;
}