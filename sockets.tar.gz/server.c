#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>

// gcc -Wall -g -o server server.c

#define LISTENQ 1
#define MAXLINE 4096

#ifndef SERVER_PORT 
# define SERVER_PORT 10002
#endif //SERVER_PORT

int main(int argc, char *argv[]){

    int listenfd;
    int sockfd;
    int n;
    int port = SERVER_PORT;
    char buf[MAXLINE];
    socklen_t clilen;
    struct sockaddr_in cliaddr;
    struct sockaddr_in servaddr;

    if (argc > 1){
        port = atoi(argv[1]);
    }

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(port);

    if (bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) != 0){
         perror("Bind failed!");
         exit(EXIT_FAILURE);
    }

    listen(listenfd, LISTENQ);
    printf("server listening on %d\n", port);
    clilen = sizeof(cliaddr);
    sockfd = accept(listenfd, (struct sockaddr *) &cliaddr, &clilen);
    for ( ; ; ) {
        memset(buf, 0, sizeof(buf));
        if ((n = read(sockfd, buf, sizeof(buf))) <= 0){
            printf("EOF found on client connecti on socket, exiting\n");
            close(sockfd);
            break;
        }
        else {
            fprintf(stdout, "message from client: <%s>\n", buf);
            write(sockfd, buf, n);
        }
    }
    printf("socket closed --- exiting\n");

    return EXIT_SUCCESS;
}